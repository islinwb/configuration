#!/bin/sh

arch_info=`arch`
case $arch_info in
"x86_64" | "amd64")
    archInfo="x86_64"
    ;;
"arm" | "armv7" | "armv7l")
    archInfo="arm32"
    ;;
"aarch64")
    archInfo="arm64"
    ;;
"i386")
    archInfo="i386"
    ;;
*)
    echo "Don't support architecture ${arch_info}!"
    exit 1
    ;;
esac
echo ${archInfo}