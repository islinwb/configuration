#!/bin/sh

CERT_PATH=/opt/IEF/Cert
VERSION_FILE=/opt/IEF/version

get_node_id() {
	NODE_HOST_NAME=`cat ${CERT_PATH}/user_config | grep -Po '"NODE_ID":".*?"' | sed 's/"//g' | cut -d":" -f2`
    if [ $? -ne 0 ]; then
        echo "Parse node id failed!"
        exit 1
    fi
	echo ${NODE_HOST_NAME}
}

get_project_id() {
    EDGE_NAMESPACE=`cat ${CERT_PATH}/user_config | grep -Po '"PROJECT_ID":".*?"' | sed 's/"//g' | cut -d":" -f2`
    if [ $? -ne 0 ]; then
        echo "Parse project id failed!"
        exit 1
    fi
    echo ${EDGE_NAMESPACE}
}

get_private_cert_file() {
    PRIVATE_CERT_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"PRIVATE_CERTIFICATE":".*?"' | sed 's/"//g' | sed 's/PRIVATE_CERTIFICATE://'`
    if [ $? -ne 0 ]; then
        echo "Parse private cert file failed!"
        exit 1
    fi
    echo ${CERT_PATH}/${PRIVATE_CERT_FILE}
}

get_private_key_file() {
    PRIVATE_KEY_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"PRIVATE_KEY":".*?"' | sed 's/"//g' | sed 's/PRIVATE_KEY://'`
    if [ $? -ne 0 ]; then
        echo "Parse private key file failed!"
        exit 1
    fi
    echo ${CERT_PATH}/${PRIVATE_KEY_FILE}
}

get_master_url() {
    MASTER_ADDR_FOREDGE=`cat ${CERT_PATH}/user_config | grep -Po '"MASTER_URL":".*?"' | sed 's/"//g' | sed 's/MASTER_URL://'`
    if [ $? -ne 0 ]; then
        echo "Parse master url failed!"
        exit 1
    fi
    echo ${MASTER_ADDR_FOREDGE}
}

get_root_cert_file() {
    ROOT_CA_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"ROOT_CA":".*?"' | sed 's/"//g' | sed 's/ROOT_CA://'`
    if [ $? -ne 0 ]; then
        echo "Parse root cert file failed!"
        exit 1
    fi
    echo ${CERT_PATH}/${ROOT_CA_FILE}
}

get_current_ief_version() {
    if [ ! -f ${VERSION_FILE} ]; then
        echo "No file ${VERSION_FILE}"
        exit 1
    fi
    version=`cat ${VERSION_FILE} | grep "ief" | cut -d":" -f2`
    if [ $? -ne 0 ]; then
        echo "Get current ief version failed!"
        exit 1
    fi
    echo ${version}
}

write_ief_version() {
    version=$1
    if [ ! -f ${VERSION_FILE} ]; then
        echo "No file ${VERSION_FILE}"
        exit 1
    fi
    if [ -z `cat ${VERSION_FILE} | grep "ief"`]; then
        echo "ief:${version}" >> ${VERSION_FILE}
    else
        sed -i "s|ief:.*|ief:${version}|g" ${VERSION_FILE}
    fi
}

print_help() {
    echo "Usage: sudo $0 {node_id|project_id|private_cert_file|private_key_file|master_url|root_cert_file}"
}

if [ ! -d ${CERT_PATH} ]; then
    echo "${CERT_PATH}: No such directory"
    exit 1
fi

if [ ! -f ${CERT_PATH}/user_config ]; then
    echo "${CERT_PATH}/user_config: No such file"
    exit 1
fi

if [ "$#" -gt 0 ]; then
    case "$1" in
        "node_id" )
            get_node_id
        ;;
        "project_id" )
            get_project_id
        ;;
        "private_cert_file")
            get_private_cert_file
        ;;
        "private_key_file")
            get_private_key_file
        ;;
        "master_url")
            get_master_url
        ;;
        "root_cert_file")
            get_root_cert_file
        ;;
        "current_ief_version")
            get_current_ief_version
        ;;
        "write_ief_version")
            write_ief_version $2
        ;;
    esac
else
    print_help "$@"
fi